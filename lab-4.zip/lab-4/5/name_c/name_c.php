<form action="#" method="POST">
	<fieldset>
		<legend>Gender</legend>
		<form action="check.php" method="POST">
	<fieldset>
		<legend>DEGREE</legend>
		<form action="/action_page.php" method="get">
			  <input type="checkbox" name="ssc" value="ssc" <?php if(isset($_POST['ssc']) && $_POST['ssc'] =="ssc"){echo "checked";}?>> SSC
			  <input type="checkbox" name="hsc" value="hsc" <?php if(isset($_POST['hsc']) && $_POST['hsc'] =="hsc"){echo "checked";}?>> HSC
			  <input type="checkbox" name="bsc" value="bsc" <?php if(isset($_POST['bsc']) && $_POST['bsc'] =="bsc"){echo "checked";}?>> BSc
			  <input type="checkbox" name="msc" value="msc" <?php if(isset($_POST['msc']) && $_POST['msc'] =="msc"){echo "checked";}?>> MSc
</form> <br/><br/>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>