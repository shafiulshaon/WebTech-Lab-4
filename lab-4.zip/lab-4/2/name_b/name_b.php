<?php
	
	if(isset($_POST['name'])){
		echo $_POST['name'];
	}
	
?>

<form action="#" method="POST">
	<fieldset>
		<legend>EMAIL</legend>
		<input type="text" name="name" value="" >i<br/><br/>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>