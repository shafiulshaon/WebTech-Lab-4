<?php
	
	if(isset($_POST['dd']) && isset($_POST['mm']) && isset($_POST['yy']))
	{
		echo $_POST['dd'].'/'.$_POST['mm'].'/'.$_POST['yy'];
	}
?>