<?php error_reporting(0);?>
<form action="#" method="post">
	<fieldset>
		<legend>Blood Group</legend>
				
		<select name="dd">
			<option value="a" <?php if($_POST['dd'] == "a"){ echo "selected";} ?>>a+</option>
			<option value="b" <?php if($_POST['dd'] == "b"){ echo "selected";} ?>>b+</option>
			<option value="ab" <?php if($_POST['dd'] == "ab"){ echo "selected";} ?>>ab+</option>
			<option value="o" <?php if($_POST['dd'] == "o"){ echo "selected";} ?>>o+</option>
		</select>
		<br/><br/>
		
		<input type="submit" name="submit" value="Submit">
		<hr/>
	</fieldset>
</form>

