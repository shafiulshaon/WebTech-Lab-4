<?php
	
	if(isset($_POST['dd'])){
		echo $_POST['dd'];
	}
?>
