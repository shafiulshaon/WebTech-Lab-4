<?php
	
	if(isset($_POST['dd'])){
		echo $_POST['dd'];
	}
?>


<form action="#" method="post">
	<fieldset>
		<legend>Blood Group</legend>
				
		<select name="dd">
			<option value="a+" >a+</option>
			<option value="b+" >b+</option>
			<option value="ab+">ab+</option>
			<option value="o+" >o+</option>
		</select>
		<br/><br/>
		
		<input type="submit" name="submit" value="Submit">
		<hr/>
	</fieldset>
</form>