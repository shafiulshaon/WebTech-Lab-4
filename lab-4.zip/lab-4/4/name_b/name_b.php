<?php
	
	if(isset($_POST['gender']))
	{
		echo $_POST['gender'];
	}
?>
<form action="#" method="POST">
	<fieldset>
		<legend>Gender</legend>
		<form>
			  <input type="radio" name="gender" value="male" checked> Male
			  <input type="radio" name="gender" value="female"> Female
			  <input type="radio" name="gender" value="other"> Other  
</form><br/><br/>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>