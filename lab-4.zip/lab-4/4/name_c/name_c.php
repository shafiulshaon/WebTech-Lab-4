<form action="#" method="POST">
	<fieldset>
		<legend>Gender</legend>
		<form>
			  <input type="radio" name="gender" value="male" <?php if($_POST['gender']=="male"){echo "checked";}?> > Male
			  <input type="radio" name="gender" value="female" <?php if($_POST['gender']=="female"){echo "checked";}?> > Female
			  <input type="radio" name="gender" value="other" <?php if($_POST['gender']=="other"){echo "checked";}?> > Other  
</form><br/><br/>
		<input type="submit" name="submit" value="Submit" >
		<hr/>
	</fieldset>
</form>