<?php
	
	if(isset($_POST['gender']))
	{
		echo $_POST['gender'];
	}
?>